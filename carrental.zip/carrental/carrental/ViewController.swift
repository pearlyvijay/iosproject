//
//  ViewController.swift
//  carrental
//
//  Created by Student on 09/11/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBOutlet weak var username: UITextField!
    
    @IBOutlet weak var password: UITextField!
    @IBAction func signin(_ sender: Any) {
        if(username.text=="pearly" && password.text=="12345"){
            performSegue(withIdentifier: "uname", sender: self)
        }
        else{
           
            let alert=UIAlertController(title: "WARNING", message: "No User Found!", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            alert.addAction(UIAlertAction(title: "CANCEL", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
}

