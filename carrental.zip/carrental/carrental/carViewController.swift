//
//  carViewController.swift
//  carrental
//
//  Created by Student on 09/11/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class carViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var amount: UILabel!
    @IBOutlet weak var noofcars: UITextField!
    
    @IBOutlet weak var mobilenumber: UILabel!
    @IBOutlet weak var mobileno: UITextField!
    @IBOutlet weak var noofdays: UITextField!
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBOutlet weak var locations: UILabel!
    @IBOutlet weak var rating: UILabel!
    @IBAction func segment(_ sender: UISegmentedControl) {
        if(sender.selectedSegmentIndex==0){
            locations.text="Location: Hyderabad"
        }
        else if(sender.selectedSegmentIndex==1){
            locations.text="Location: Banglore"
        }
        else{
            locations.text="Location: Delhi"
        }
    }
    
    @IBAction func swtch(_ sender: UISwitch) {
        if(sender.isOn==false){
            
            let alert1=UIAlertController(title:"Warning!", message: "You Need Driver's Lisense",preferredStyle: .alert)
            alert1.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert1, animated: true, completion: nil)
    }
    
    }
    @IBAction func generatebill(_ sender: Any) {
        
        let a=Int(noofcars.text!)
        let b=Int(noofdays.text!)
        let strt=Int(mobileno.text!)
        
        let c=a!*b!*500
        mobilenumber.text="Mobile No=\(strt!)"
        amount.text="Total Amount=\(c)"
        
    }
    

    
    @IBAction func book(_ sender: Any) {
        if(noofdays.text=="" || noofcars.text=="" || mobileno.text==""){
            
            let alert1=UIAlertController(title:"Warning!", message: "Required Fields are Missing",preferredStyle: .alert)
            alert1.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert1, animated: true, completion: nil)
            
        }
        else{
        let alert1=UIAlertController(title:"Booking Successful!", message: "Your Booking is successful. Thank you for Choosing Us",preferredStyle: .alert)
        alert1.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert1, animated: true, completion: nil)
    }
    }
        
    @IBAction func slider(_ sender: UISlider) {
        rating.text=String(Int(sender.value))
    }
}
